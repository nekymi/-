﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms17
{
    public partial class Form2 : Form
    {
        private Form1 mainForm;
        private Button btnOpen;
        private Button btnExit;
        private ListBox listBoxFiles;
        public Form2(Form1 form1)
        {
            InitializeComponent();
            mainForm = form1;
            this.Text = "Результаты поиска файлов";
            this.ClientSize = new System.Drawing.Size(600, 400);

            Label lbl = new Label
            {
                Text = "Найденные файлы:",
                AutoSize = true,
                Location = new System.Drawing.Point(10, 10)
            };
            this.Controls.Add(lbl);

            listBoxFiles = new ListBox
            {
                Location = new System.Drawing.Point(10, 30),
                Size = new System.Drawing.Size(560, 280)
            };
            this.Controls.Add(listBoxFiles);

            btnOpen = new Button
            {
                Text = "Открыть",
                Location = new System.Drawing.Point(10, 320),
                Size = new System.Drawing.Size(100, 30)
            };
            btnOpen.Click += BtnOpen_Click;
            this.Controls.Add(btnOpen);

            btnExit = new Button
            {
                Text = "Выход",
                Location = new System.Drawing.Point(120, 320),
                Size = new System.Drawing.Size(100, 30)
            };
            btnExit.Click += (s, e) => this.Close();
            this.Controls.Add(btnExit);
        }
        public void LoadFiles(string[] filePaths)
        {
            listBoxFiles.Items.Clear();
            listBoxFiles.Items.AddRange(filePaths);
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            if (listBoxFiles.SelectedItem != null)
            {
                string selectedFile = listBoxFiles.SelectedItem.ToString();
                try
                {
                    string content = File.ReadAllText(selectedFile);
                    mainForm.ПоказатьТекстВRichTextBox(content); // передаём текст в Form1
                    this.Close(); // закрываем Form2
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при открытии файла: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите файл из списка.");
            }
        }
    }
}
