﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TextFileLib;
using System.IO;
using System.Drawing.Printing;


namespace WindowsForms17
{
    public partial class Form1 : Form
    {
        private string fileName;
        private bool fileSaved = true;

        private MenuStrip menuStrip1;
        private ToolStrip toolStrip1;
        private RichTextBox richTextBox1;

        private FontDialog fontDialog1;
        private ColorDialog colorDialog1;

        private ToolStripMenuItem параметрыToolStripMenuItem;
        private ToolStripMenuItem шрифтToolStripMenuItem;
        private ToolStripMenuItem показатьСкрытьПанельToolStripMenuItem;

        private ToolStripMenuItem справкаToolStripMenuItem;
        private ToolStripMenuItem обАвтореToolStripMenuItem;
        private ToolStripMenuItem оПрограммеToolStripMenuItem;

        private ToolStripButton btnOpen;
        private ToolStripButton btnSave;
        private ToolStripButton btnPrint;
        private ToolStripButton btnFont;

        public Form1()
        {
            InitializeComponent();
            this.Text = "Работа с текстовыми файлами";
        this.ClientSize = new Size(700, 500);
        this.MinimumSize = new Size(300, 200);

        // Создаём ToolStripContainer
        var toolStripContainer = new ToolStripContainer();
        toolStripContainer.Dock = DockStyle.Fill;

        // Меню
        menuStrip1 = new MenuStrip();

        var файлToolStripMenuItem = new ToolStripMenuItem("Файл");
        var создатьToolStripMenuItem = new ToolStripMenuItem("Создать", null, создатьToolStripMenuItem_Click);
        var открытьToolStripMenuItem = new ToolStripMenuItem("Открыть", null, открытьToolStripMenuItem_Click);
        var сохранитьToolStripMenuItem = new ToolStripMenuItem("Сохранить", null, сохранитьToolStripMenuItem_Click);
        var сохранитьКакToolStripMenuItem = new ToolStripMenuItem("Сохранить как...", null, сохранитьКакToolStripMenuItem_Click);
        var печатьToolStripMenuItem = new ToolStripMenuItem("Печать", null, печатьToolStripMenuItem_Click);
        var выходToolStripMenuItem = new ToolStripMenuItem("Выход", null, выходToolStripMenuItem_Click);

        файлToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[]
        {
            создатьToolStripMenuItem,
            открытьToolStripMenuItem,
            сохранитьToolStripMenuItem,
            сохранитьКакToolStripMenuItem,
            печатьToolStripMenuItem,
            new ToolStripSeparator(),
            выходToolStripMenuItem
        });

        параметрыToolStripMenuItem = new ToolStripMenuItem("Параметры");
        шрифтToolStripMenuItem = new ToolStripMenuItem("Шрифт", null, шрифтToolStripMenuItem_Click);
        показатьСкрытьПанельToolStripMenuItem = new ToolStripMenuItem("Показать/Скрыть панель инструментов", null, показатьСкрытьПанельToolStripMenuItem_Click);
        параметрыToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[]
        {
            шрифтToolStripMenuItem,
            показатьСкрытьПанельToolStripMenuItem
        });

        var анализToolStripMenuItem = new ToolStripMenuItem("Поиск");
        var найтиФайлыToolStripMenuItem = new ToolStripMenuItem("Найти файлы...", null, найтиФайлыToolStripMenuItem_Click);
        анализToolStripMenuItem.DropDownItems.Add(найтиФайлыToolStripMenuItem);

        справкаToolStripMenuItem = new ToolStripMenuItem("Справка");
        обАвтореToolStripMenuItem = new ToolStripMenuItem("Об авторе", null, обАвтореToolStripMenuItem_Click);
        оПрограммеToolStripMenuItem = new ToolStripMenuItem("О программе", null, оПрограммеToolStripMenuItem_Click);
        справкаToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[]
        {
            обАвтореToolStripMenuItem,
            оПрограммеToolStripMenuItem
        });

        menuStrip1.Items.AddRange(new ToolStripItem[]
        {
            файлToolStripMenuItem,
            параметрыToolStripMenuItem,
            анализToolStripMenuItem,
            справкаToolStripMenuItem
        });

        // Панель инструментов
        toolStrip1 = new ToolStrip();

        btnOpen = new ToolStripButton("Открыть");
        btnSave = new ToolStripButton("Сохранить");
        btnPrint = new ToolStripButton("Печать");
        btnFont = new ToolStripButton("Шрифт");

        btnOpen.Click += открытьToolStripMenuItem_Click;
        btnSave.Click += сохранитьToolStripMenuItem_Click;
        btnPrint.Click += печатьToolStripMenuItem_Click;
        btnFont.Click += шрифтToolStripMenuItem_Click;

        toolStrip1.Items.AddRange(new ToolStripItem[]
        {
            btnOpen,
            btnSave,
            btnPrint,
            btnFont
        });

        // RichTextBox
        richTextBox1 = new RichTextBox();
        richTextBox1.Dock = DockStyle.Fill;
        richTextBox1.Font = new Font("Arial", 12);
        richTextBox1.WordWrap = true;
        richTextBox1.Multiline = true;
        richTextBox1.ScrollBars = RichTextBoxScrollBars.Vertical;
        richTextBox1.TextChanged += richTextBox1_TextChanged;

        // Диалоги
        fontDialog1 = new FontDialog();
        colorDialog1 = new ColorDialog();

        // Добавляем всё в контейнер
        toolStripContainer.TopToolStripPanel.Controls.Add(menuStrip1);
        toolStripContainer.TopToolStripPanel.Controls.Add(toolStrip1);
        toolStripContainer.ContentPanel.Controls.Add(richTextBox1);

        this.Controls.Add(toolStripContainer);
        this.MainMenuStrip = menuStrip1;

        // Инициализация
        fileName = string.Empty;
        fileSaved = true;
    
        }

        private void CreateFile(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!fileSaved)
            {
                DialogResult dr = MessageBox.Show("Файл не сохранен. Сохранить изменения?", "Создать файл", MessageBoxButtons.YesNoCancel);
                if (dr == DialogResult.Yes)
                    СохранитьФайл();
                else if (dr == DialogResult.Cancel)
                    return;
            }

            richTextBox1.Clear();
            fileName = string.Empty;
            fileSaved = true;
            this.Text = "Работа с текстовыми файлами - Новый файл";
        }
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            fileSaved = false;
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!fileSaved)
            {
                DialogResult dr = MessageBox.Show("Файл не сохранен. Сохранить изменения?", "Внимание", MessageBoxButtons.YesNoCancel);
                if (dr == DialogResult.Yes)
                    СохранитьФайл();
                else if (dr == DialogResult.Cancel)
                    return;
            }

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    richTextBox1.Text = File.ReadAllText(openFileDialog.FileName);
                    fileName = openFileDialog.FileName;
                    fileSaved = true;
                    this.Text = "Работа с текстовыми файлами - " + Path.GetFileName(fileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при открытии файла: " + ex.Message);
                }
            }
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            СохранитьФайл();
        }

        private void сохранитьКакToolStripMenuItem_Click(object sender, EventArgs e)
        {
            СохранитьФайлКак();
        }

        private void СохранитьФайл()
        {
            try
            {
                if (string.IsNullOrEmpty(fileName))
                    СохранитьФайлКак();
                else
                {
                    File.WriteAllText(fileName, richTextBox1.Text);
                    fileSaved = true;
                    this.Text = "Работа с текстовыми файлами - " + Path.GetFileName(fileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении файла: " + ex.Message);
            }
        }

        private void СохранитьФайлКак()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    File.WriteAllText(saveFileDialog.FileName, richTextBox1.Text);
                    fileName = saveFileDialog.FileName;
                    fileSaved = true;
                    this.Text = "Работа с текстовыми файлами - " + Path.GetFileName(fileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при сохранении файла: " + ex.Message);
                }
            }
        }

        private void печатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDocument printDoc = new PrintDocument();
            printDoc.PrintPage += PrintDoc_PrintPage;

            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDoc;

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    printDoc.Print();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при печати: " + ex.Message);
                }
            }
        }

        private void PrintDoc_PrintPage(object sender, PrintPageEventArgs e)
        {
            e.Graphics.DrawString(richTextBox1.Text, richTextBox1.Font, Brushes.Black, e.MarginBounds.Left, e.MarginBounds.Top);
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!fileSaved)
            {
                DialogResult dr = MessageBox.Show("Файл не сохранен. Сохранить изменения?", "Внимание", MessageBoxButtons.YesNoCancel);
                if (dr == DialogResult.Yes)
                    СохранитьФайл();
                else if (dr == DialogResult.Cancel)
                    return;
            }
            this.Close();
        }

        private void шрифтToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.Font = richTextBox1.Font;
            fontDialog1.Color = richTextBox1.ForeColor;

            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.Font = fontDialog1.Font;
                richTextBox1.ForeColor = fontDialog1.Color;
            }
        }

        private void показатьСкрытьПанельToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStrip1.Visible = !toolStrip1.Visible;
        }

        private void обАвтореToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Автор: Белобаба Иван, группа 329198", "Об авторе", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form aboutForm = new Form();
            aboutForm.Text = "О программе";
            aboutForm.Size = new Size(350, 180);
            aboutForm.FormBorderStyle = FormBorderStyle.FixedDialog;
            aboutForm.StartPosition = FormStartPosition.CenterParent;
            aboutForm.MaximizeBox = false;
            aboutForm.MinimizeBox = false;

            Label lbl = new Label();
            lbl.Text = "Программа для работы с текстовыми файлами.\n© 2025 Иванов И.И.";
            lbl.AutoSize = true;
            lbl.Location = new Point(20, 20);
            aboutForm.Controls.Add(lbl);

            Button btnClose = new Button();
            btnClose.Text = "Закрыть";
            btnClose.Size = new Size(80, 30);
            btnClose.Location = new Point(aboutForm.ClientSize.Width / 2 - 40, aboutForm.ClientSize.Height - 60);
            btnClose.Anchor = AnchorStyles.Bottom;
            btnClose.Click += (s, ev) => aboutForm.Close();
            aboutForm.Controls.Add(btnClose);

            aboutForm.ShowDialog();
        }
        public void ПоказатьТекстВRichTextBox(string text)
        {
            richTextBox1.Text = text;
        }
        private void найтиФайлыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    string path = folderDialog.SelectedPath;
                    string inputMask = Microsoft.VisualBasic.Interaction.InputBox("Введите маску файла (например, *.txt):", "Поиск файлов", "*.txt");

                    try
                    {
                        string[] foundFiles = Directory.GetFiles(path, inputMask, SearchOption.AllDirectories);

                        Form2 resultsForm = new Form2(this);
                        resultsForm.LoadFiles(foundFiles);
                        resultsForm.ShowDialog();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при поиске файлов: " + ex.Message);
                    }
                }
            }
        }
    }
}
