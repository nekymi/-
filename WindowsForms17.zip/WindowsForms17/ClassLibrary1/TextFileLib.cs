﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text.RegularExpressions;

namespace TextFileLib
{
    /// <summary>Класс для работы с текстовыми файлами</summary>
    public class TextFile : IComparable<TextFile>
    {
        private string path;
        private string text;

        public string Text => text;
        public string Path => path;

        public TextFile(string path)
        {
            this.path = path;
        }

        /// <summary>Открытие текстового файла</summary>
        public void OpenFile()
        {
            using (StreamReader sr = new StreamReader(path, System.Text.Encoding.UTF8))
            {
                text = sr.ReadToEnd();
            }
        }

        /// <summary>Сохранение текста в файл</summary>
        public void SaveFile(string content)
        {
            using (StreamWriter sw = new StreamWriter(path, false, System.Text.Encoding.UTF8))
            {
                sw.Write(content);
            }
        }

        /// <summary>Печать текста на принтер</summary>
        public bool PrintResult(Font printFont)
        {
            try
            {
                StreamReader streamToPrint = new StreamReader(path, System.Text.Encoding.GetEncoding(1251));
                PrintDocument pd = new PrintDocument();
                pd.PrintPage += (sender, ev) =>
                {
                    float linesPerPage = ev.MarginBounds.Height / printFont.GetHeight(ev.Graphics);
                    float yPos = 0;
                    int count = 0;
                    string line;
                    while (count < linesPerPage && (line = streamToPrint.ReadLine()) != null)
                    {
                        yPos = ev.MarginBounds.Top + count * printFont.GetHeight(ev.Graphics);
                        ev.Graphics.DrawString(line, printFont, Brushes.Black, ev.MarginBounds.Left, yPos);
                        count++;
                    }
                    ev.HasMorePages = !streamToPrint.EndOfStream;

                    if (!ev.HasMorePages)
                    {
                        streamToPrint.Dispose();
                    }
                };
                pd.Print();
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Подсчет количества слов</summary>
        public int CountWords()
        {
            if (string.IsNullOrWhiteSpace(Text))
                return 0;

            // Слова: только буквы и цифры, без знаков препинания
            var matches = Regex.Matches(Text, @"[A-Za-zА-Яа-яЁё0-9]+");
            return matches.Count;
        }


        /// <summary>Поиск самых длинных слов</summary>
        public (List<string> Words, int MaxLength) FindLongestWords()
        {
            var words = Regex.Matches(text ?? "", @"\b[\p{L}]+\b")
                             .Cast<Match>()
                             .Select(m => m.Value)
                             .ToList();
            if (words.Count == 0)
                return (new List<string>(), 0);

            int maxLen = words.Max(w => w.Length);
            var longest = words.Where(w => w.Length == maxLen).Select(w => w.ToLower()).Distinct().ToList();
            return (longest, maxLen);
        }

        /// <summary>Подсчет количества символов</summary>
        public int GetCharCount()
        {
            return string.IsNullOrEmpty(text) ? 0 : text.Length;
        }

        public static bool operator ==(TextFile a, TextFile b)
        {
            if (ReferenceEquals(a, b)) return true;
            if (ReferenceEquals(a, null) || ReferenceEquals(b, null)) return false;
            return a.GetCharCount() == b.GetCharCount();
        }

        public static bool operator !=(TextFile a, TextFile b)
        {
            return !(a == b);
        }

        public override bool Equals(object obj)
        {
            if (obj is TextFile tf) return this == tf;
            return false;
        }

        public override int GetHashCode()
        {
            return path != null ? path.GetHashCode() : 0;
        }

        public int CompareTo(TextFile other)
        {
            if (other == null) return 1;
            return this.GetCharCount().CompareTo(other.GetCharCount());
        }

        /// <summary>Поиск файлов в директории</summary>
        public static List<TextFile> FindFiles(string directory)
        {
            var paths = Directory.GetFiles(directory, "*.txt");
            var result = new List<TextFile>();
            foreach (var p in paths)
            {
                result.Add(new TextFile(p));
            }
            return result;
        }
    }

    /// <summary>Сортировка по имени файла</summary>
    public class SortByName : IComparer<TextFile>
    {
        public int Compare(TextFile x, TextFile y)
        {
            if (x == null || y == null) return 0;
            return x.Path.CompareTo(y.Path);
        }
    }

    /// <summary>Сортировка по количеству слов</summary>
    public class SortByWordCount : IComparer<TextFile>
    {
        public int Compare(TextFile x, TextFile y)
        {
            if (x == null || y == null) return 0;
            return x.CountWords().CompareTo(y.CountWords());
        }
    }

    /// <summary>Сортировка по количеству символов</summary>
    public class SortByCharCount : IComparer<TextFile>
    {
        public int Compare(TextFile x, TextFile y)
        {
            if (x == null || y == null) return 0;
            return x.GetCharCount().CompareTo(y.GetCharCount());
        }
    }
}
