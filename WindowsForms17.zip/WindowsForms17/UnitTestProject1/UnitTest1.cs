﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TextFileLib;
using System.IO;

namespace TextFileLib.Tests
{
    [TestClass]
    public class TextFileTests
    {
        [TestMethod]
        public void CountWordsTest()
        {
            var path = "test.txt";
            File.WriteAllText(path, "Привет, мир! Это тест.");
            var tf = new TextFile(path);
            tf.OpenFile();
            Assert.AreEqual(4, tf.CountWords());
        }

        [TestMethod]
        public void EqualOperatorTest()
        {
            File.WriteAllText("1.txt", "Привет");
            File.WriteAllText("2.txt", "Мир!");
            var tf1 = new TextFile("1.txt");
            var tf2 = new TextFile("2.txt");
            tf1.OpenFile();
            tf2.OpenFile();
            Assert.AreNotEqual(tf1, tf2);
        }

        [TestMethod]
        public void FindLongestWordsTest()
        {
            var path = "long.txt";
            File.WriteAllText(path, "Кот программирование собака");
            var tf = new TextFile(path);
            tf.OpenFile();
            var result = tf.FindLongestWords();
            CollectionAssert.Contains(result.Words, "программирование");
            Assert.AreEqual(16, result.MaxLength);
        }
    }
}
