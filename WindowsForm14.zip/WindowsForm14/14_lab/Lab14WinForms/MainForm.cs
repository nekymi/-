﻿using System;
using System.Windows.Forms;

namespace Lab14WinForms
{
    public partial class MainForm : Form
    {
        public delegate void Del(double[] x, double[] y, string title);
        public event Del OnDataReady;

        private GraphForm graphForm;
        private DiagramStyle diagramStyle = new DiagramStyle();
        private double[] lastXs, lastYs;
        private string lastTitle;

        private DataGridView dataGridView; 

        public MainForm()
        {
            InitializeComponent();
            dataGridView = new DataGridView
            {
                Parent = this,
                Location = new System.Drawing.Point(350, 20),
                Size = new System.Drawing.Size(200, 300),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
            };
            dataGridView.Columns.Add("X", "X");
            dataGridView.Columns.Add("Y", "Y");

            cmbFunction.Items.AddRange(new object[]
            {
                "Sin(a·x)",
                "Sin(a·x/2)",
                "-Sin(a·x)"
            });
            cmbFunction.SelectedIndex = 0;

            cmbUnits.Items.AddRange(new object[]
            {
                "Радианы",
                "Градусы"
            });
            cmbUnits.SelectedIndex = 0;

            txtXn.TextChanged += (s, e) => ValidateInputs();
            txtXk.TextChanged += (s, e) => ValidateInputs();
            txtDX.TextChanged += (s, e) => ValidateInputs();
            numA.ValueChanged += (s, e) => ValidateInputs();
            ValidateInputs();

            btnCompute.Click += btnCompute_Click;
            btnStyle.Click += btnStyle_Click;
        }

        private void ValidateInputs()
        {
            bool ok = double.TryParse(txtXn.Text, out double xn)
                      && double.TryParse(txtXk.Text, out double xk)
                      && double.TryParse(txtDX.Text, out double dx)
                      && xn < xk && dx > 0;
            btnCompute.Enabled = ok;
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            double Xn = double.Parse(txtXn.Text);
            double Xk = double.Parse(txtXk.Text);
            double dX = double.Parse(txtDX.Text);
            double a = (double)numA.Value;
            bool inDeg = cmbUnits.SelectedItem.ToString() == "Градусы";

            Fun func = x => Math.Sin(a * x);

            switch (cmbFunction.SelectedIndex)
            {
                case 0: func = x => Math.Sin(a * x); break;
                case 1: func = x => Math.Sin(a * x / 2); break;
                case 2: func = x => -Math.Sin(a * x); break;
            }

            FunctionCalculator.Compute(func, Xn, Xk, dX, inDeg, out double[] xs, out double[] ys);
            string title = $"{cmbFunction.SelectedItem}, a={a}";

            lastXs = xs;
            lastYs = ys;
            lastTitle = title;

            dataGridView.Rows.Clear();
            for (int i = 0; i < xs.Length; i++)
            {
                dataGridView.Rows.Add(xs[i], ys[i]);
            }

            if (graphForm == null || graphForm.IsDisposed)
            {
                graphForm = new GraphForm(diagramStyle);
                OnDataReady += graphForm.RefreshDiagram;
                graphForm.FormClosed += (s, args) => OnDataReady -= graphForm.RefreshDiagram;
                graphForm.Show(this);
            }

            OnDataReady?.Invoke(xs, ys, title);
        }

        private void txtXn_TextChanged(object sender, EventArgs e) { }
        private void lblXn_Click(object sender, EventArgs e) { }
        private void lblXk_Click(object sender, EventArgs e) { }
        private void txtXk_TextChanged(object sender, EventArgs e) { }

        private void btnStyle_Click(object sender, EventArgs e)
        {
            using (var styleForm = new StyleForm(diagramStyle))
            {
                if (styleForm.ShowDialog() == DialogResult.OK && lastXs != null)
                {
                    OnDataReady?.Invoke(lastXs, lastYs, lastTitle);
                }
            }
        }
    }
}
