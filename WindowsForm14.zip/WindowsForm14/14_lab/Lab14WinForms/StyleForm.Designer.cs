﻿namespace Lab14WinForms
{
    partial class StyleForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.CheckBox chkTitle, chkLegend;
        private System.Windows.Forms.GroupBox grpChartType;
        private System.Windows.Forms.RadioButton rbSpline, rbFastPoint;
        private System.Windows.Forms.Label lblLineWidth;
        private System.Windows.Forms.NumericUpDown numLineWidth;
        private System.Windows.Forms.Button btnLineColor, btnBackColor, btnOK, btnCancel;
        private System.Windows.Forms.ColorDialog colorDialog1;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.chkTitle = new System.Windows.Forms.CheckBox();
            this.chkLegend = new System.Windows.Forms.CheckBox();
            this.grpChartType = new System.Windows.Forms.GroupBox();
            this.rbFastPoint = new System.Windows.Forms.RadioButton();
            this.rbSpline = new System.Windows.Forms.RadioButton();
            this.lblLineWidth = new System.Windows.Forms.Label();
            this.numLineWidth = new System.Windows.Forms.NumericUpDown();
            this.btnLineColor = new System.Windows.Forms.Button();
            this.btnBackColor = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.grpChartType.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLineWidth)).BeginInit();
            this.SuspendLayout();
            // 
            // chkTitle
            // 
            this.chkTitle.AutoSize = true;
            this.chkTitle.Location = new System.Drawing.Point(68, 12);
            this.chkTitle.Name = "chkTitle";
            this.chkTitle.Size = new System.Drawing.Size(164, 20);
            this.chkTitle.TabIndex = 0;
            this.chkTitle.Text = "Показать заголовок";
            this.chkTitle.UseVisualStyleBackColor = true;
            // 
            // chkLegend
            // 
            this.chkLegend.AutoSize = true;
            this.chkLegend.Location = new System.Drawing.Point(69, 50);
            this.chkLegend.Name = "chkLegend";
            this.chkLegend.Size = new System.Drawing.Size(149, 20);
            this.chkLegend.TabIndex = 1;
            this.chkLegend.Text = "Показать легенду";
            this.chkLegend.UseVisualStyleBackColor = true;
            // 
            // grpChartType
            // 
            this.grpChartType.Controls.Add(this.rbFastPoint);
            this.grpChartType.Controls.Add(this.rbSpline);
            this.grpChartType.Location = new System.Drawing.Point(63, 76);
            this.grpChartType.Name = "grpChartType";
            this.grpChartType.Size = new System.Drawing.Size(200, 60);
            this.grpChartType.TabIndex = 2;
            this.grpChartType.TabStop = false;
            this.grpChartType.Text = "Тип графика";
            // 
            // rbFastPoint
            // 
            this.rbFastPoint.AutoSize = true;
            this.rbFastPoint.Location = new System.Drawing.Point(6, 39);
            this.rbFastPoint.Name = "rbFastPoint";
            this.rbFastPoint.Size = new System.Drawing.Size(68, 20);
            this.rbFastPoint.TabIndex = 1;
            this.rbFastPoint.TabStop = true;
            this.rbFastPoint.Text = "Точки";
            this.rbFastPoint.UseVisualStyleBackColor = true;
            // 
            // rbSpline
            // 
            this.rbSpline.AutoSize = true;
            this.rbSpline.Location = new System.Drawing.Point(6, 19);
            this.rbSpline.Name = "rbSpline";
            this.rbSpline.Size = new System.Drawing.Size(130, 20);
            this.rbSpline.TabIndex = 0;
            this.rbSpline.TabStop = true;
            this.rbSpline.Text = "Гладкая кривая";
            this.rbSpline.UseVisualStyleBackColor = true;
            // 
            // lblLineWidth
            // 
            this.lblLineWidth.AutoSize = true;
            this.lblLineWidth.Location = new System.Drawing.Point(65, 144);
            this.lblLineWidth.Name = "lblLineWidth";
            this.lblLineWidth.Size = new System.Drawing.Size(111, 16);
            this.lblLineWidth.TabIndex = 3;
            this.lblLineWidth.Text = "Толщина линии:";
            // 
            // numLineWidth
            // 
            this.numLineWidth.Location = new System.Drawing.Point(180, 142);
            this.numLineWidth.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numLineWidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLineWidth.Name = "numLineWidth";
            this.numLineWidth.Size = new System.Drawing.Size(60, 22);
            this.numLineWidth.TabIndex = 4;
            this.numLineWidth.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // btnLineColor
            // 
            this.btnLineColor.Location = new System.Drawing.Point(99, 208);
            this.btnLineColor.Name = "btnLineColor";
            this.btnLineColor.Size = new System.Drawing.Size(113, 23);
            this.btnLineColor.TabIndex = 5;
            this.btnLineColor.Text = "Цвет линии";
            this.btnLineColor.UseVisualStyleBackColor = true;
            // 
            // btnBackColor
            // 
            this.btnBackColor.Location = new System.Drawing.Point(99, 170);
            this.btnBackColor.Name = "btnBackColor";
            this.btnBackColor.Size = new System.Drawing.Size(113, 23);
            this.btnBackColor.TabIndex = 6;
            this.btnBackColor.Text = "Цвет фона";
            this.btnBackColor.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(62, 251);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 7;
            this.btnOK.Text = "ОК";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(165, 251);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // StyleForm
            // 
            this.ClientSize = new System.Drawing.Size(343, 308);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnBackColor);
            this.Controls.Add(this.btnLineColor);
            this.Controls.Add(this.numLineWidth);
            this.Controls.Add(this.lblLineWidth);
            this.Controls.Add(this.grpChartType);
            this.Controls.Add(this.chkLegend);
            this.Controls.Add(this.chkTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "StyleForm";
            this.Text = "Настройки диаграммы";
            this.grpChartType.ResumeLayout(false);
            this.grpChartType.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLineWidth)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
