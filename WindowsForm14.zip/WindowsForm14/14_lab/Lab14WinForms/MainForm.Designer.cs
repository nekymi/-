﻿namespace Lab14WinForms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblXn, lblXk, lblDx, lblA, lblFunction, lblUnits;
        private System.Windows.Forms.TextBox txtXn, txtXk, txtDX;
        private System.Windows.Forms.NumericUpDown numA;
        private System.Windows.Forms.ComboBox cmbFunction, cmbUnits;
        private System.Windows.Forms.Button btnCompute, btnStyle;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblXn = new System.Windows.Forms.Label();
            this.txtXn = new System.Windows.Forms.TextBox();
            this.lblXk = new System.Windows.Forms.Label();
            this.txtXk = new System.Windows.Forms.TextBox();
            this.lblDx = new System.Windows.Forms.Label();
            this.txtDX = new System.Windows.Forms.TextBox();
            this.lblA = new System.Windows.Forms.Label();
            this.numA = new System.Windows.Forms.NumericUpDown();
            this.lblFunction = new System.Windows.Forms.Label();
            this.cmbFunction = new System.Windows.Forms.ComboBox();
            this.lblUnits = new System.Windows.Forms.Label();
            this.cmbUnits = new System.Windows.Forms.ComboBox();
            this.btnCompute = new System.Windows.Forms.Button();
            this.btnStyle = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numA)).BeginInit();
            this.SuspendLayout();
            // 
            // lblXn
            // 
            this.lblXn.AutoSize = true;
            this.lblXn.Location = new System.Drawing.Point(79, 32);
            this.lblXn.Name = "lblXn";
            this.lblXn.Size = new System.Drawing.Size(23, 16);
            this.lblXn.TabIndex = 0;
            this.lblXn.Text = "Xₙ:";
            this.lblXn.Click += new System.EventHandler(this.lblXn_Click);
            // 
            // txtXn
            // 
            this.txtXn.Location = new System.Drawing.Point(112, 29);
            this.txtXn.Name = "txtXn";
            this.txtXn.Size = new System.Drawing.Size(60, 22);
            this.txtXn.TabIndex = 1;
            this.txtXn.TextChanged += new System.EventHandler(this.txtXn_TextChanged);
            // 
            // lblXk
            // 
            this.lblXk.AutoSize = true;
            this.lblXk.Location = new System.Drawing.Point(79, 95);
            this.lblXk.Name = "lblXk";
            this.lblXk.Size = new System.Drawing.Size(22, 16);
            this.lblXk.TabIndex = 2;
            this.lblXk.Text = "Xₖ:";
            this.lblXk.Click += new System.EventHandler(this.lblXk_Click);
            // 
            // txtXk
            // 
            this.txtXk.Location = new System.Drawing.Point(112, 92);
            this.txtXk.Name = "txtXk";
            this.txtXk.Size = new System.Drawing.Size(60, 22);
            this.txtXk.TabIndex = 3;
            this.txtXk.TextChanged += new System.EventHandler(this.txtXk_TextChanged);
            // 
            // lblDx
            // 
            this.lblDx.AutoSize = true;
            this.lblDx.Location = new System.Drawing.Point(206, 29);
            this.lblDx.Name = "lblDx";
            this.lblDx.Size = new System.Drawing.Size(26, 16);
            this.lblDx.TabIndex = 4;
            this.lblDx.Text = "dX:";
            // 
            // txtDX
            // 
            this.txtDX.Location = new System.Drawing.Point(239, 26);
            this.txtDX.Name = "txtDX";
            this.txtDX.Size = new System.Drawing.Size(60, 22);
            this.txtDX.TabIndex = 5;
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(216, 92);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(18, 16);
            this.lblA.TabIndex = 6;
            this.lblA.Text = "a:";
            // 
            // numA
            // 
            this.numA.DecimalPlaces = 2;
            this.numA.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numA.Location = new System.Drawing.Point(239, 89);
            this.numA.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numA.Name = "numA";
            this.numA.Size = new System.Drawing.Size(60, 22);
            this.numA.TabIndex = 7;
            this.numA.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblFunction
            // 
            this.lblFunction.AutoSize = true;
            this.lblFunction.Location = new System.Drawing.Point(57, 174);
            this.lblFunction.Name = "lblFunction";
            this.lblFunction.Size = new System.Drawing.Size(67, 16);
            this.lblFunction.TabIndex = 8;
            this.lblFunction.Text = "Функция:";
            // 
            // cmbFunction
            // 
            this.cmbFunction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFunction.FormattingEnabled = true;
            this.cmbFunction.Location = new System.Drawing.Point(141, 171);
            this.cmbFunction.Name = "cmbFunction";
            this.cmbFunction.Size = new System.Drawing.Size(150, 24);
            this.cmbFunction.TabIndex = 9;
            // 
            // lblUnits
            // 
            this.lblUnits.AutoSize = true;
            this.lblUnits.Location = new System.Drawing.Point(54, 233);
            this.lblUnits.Name = "lblUnits";
            this.lblUnits.Size = new System.Drawing.Size(70, 16);
            this.lblUnits.TabIndex = 10;
            this.lblUnits.Text = "Единицы:";
            // 
            // cmbUnits
            // 
            this.cmbUnits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUnits.FormattingEnabled = true;
            this.cmbUnits.Location = new System.Drawing.Point(141, 230);
            this.cmbUnits.Name = "cmbUnits";
            this.cmbUnits.Size = new System.Drawing.Size(104, 24);
            this.cmbUnits.TabIndex = 11;
            // 
            // btnCompute
            // 
            this.btnCompute.Location = new System.Drawing.Point(53, 291);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(97, 23);
            this.btnCompute.TabIndex = 12;
            this.btnCompute.Text = "Вычислить";
            this.btnCompute.UseVisualStyleBackColor = true;
            // 
            // btnStyle
            // 
            this.btnStyle.Location = new System.Drawing.Point(198, 291);
            this.btnStyle.Name = "btnStyle";
            this.btnStyle.Size = new System.Drawing.Size(101, 23);
            this.btnStyle.TabIndex = 13;
            this.btnStyle.Text = "Настройки";
            this.btnStyle.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(543, 365);
            this.Controls.Add(this.btnStyle);
            this.Controls.Add(this.btnCompute);
            this.Controls.Add(this.cmbUnits);
            this.Controls.Add(this.lblUnits);
            this.Controls.Add(this.cmbFunction);
            this.Controls.Add(this.lblFunction);
            this.Controls.Add(this.numA);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.txtDX);
            this.Controls.Add(this.lblDx);
            this.Controls.Add(this.txtXk);
            this.Controls.Add(this.lblXk);
            this.Controls.Add(this.txtXn);
            this.Controls.Add(this.lblXn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "Программа для построения функций";
            ((System.ComponentModel.ISupportInitialize)(this.numA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
