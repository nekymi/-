﻿using System.Drawing;
using System.Windows.Forms.DataVisualization.Charting;

namespace Lab14WinForms
{
    public class DiagramStyle
    {
        public bool ShowTitle { get; set; } = true;
        public bool ShowLegend { get; set; } = true;
        public SeriesChartType ChartType { get; set; } = SeriesChartType.Spline;
        public int LineWidth { get; set; } = 2;
        public Color LineColor { get; set; } = Color.Blue;
        public Color BackgroundColor { get; set; } = Color.White;
        public string TitleFontName { get; set; } = "Tahoma";
        public float TitleFontSize { get; set; } = 14f;
    }
}
