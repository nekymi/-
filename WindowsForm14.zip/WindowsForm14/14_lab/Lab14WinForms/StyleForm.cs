﻿using System;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Lab14WinForms
{
    public partial class StyleForm : Form
    {
        private readonly DiagramStyle style;

        public StyleForm(DiagramStyle style)
        {
            InitializeComponent();
            this.style = style;

            // Инициализируем контролы
            chkTitle.Checked      = style.ShowTitle;
            chkLegend.Checked     = style.ShowLegend;
            rbSpline.Checked      = style.ChartType == SeriesChartType.Spline;
            rbFastPoint.Checked   = style.ChartType == SeriesChartType.FastPoint;
            numLineWidth.Value    = style.LineWidth;
            btnLineColor.BackColor = style.LineColor;
            btnBackColor.BackColor = style.BackgroundColor;

            btnLineColor.Click += (s, e) =>
            {
                if (colorDialog1.ShowDialog() == DialogResult.OK)
                    btnLineColor.BackColor = colorDialog1.Color;
            };
            btnBackColor.Click += (s, e) =>
            {
                if (colorDialog1.ShowDialog() == DialogResult.OK)
                    btnBackColor.BackColor = colorDialog1.Color;
            };

            btnOK.Click     += (s, e) => ApplyAndClose();
            btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;
        }

        private void ApplyAndClose()
        {
            style.ShowTitle      = chkTitle.Checked;
            style.ShowLegend     = chkLegend.Checked;
            style.ChartType      = rbSpline.Checked
                                    ? SeriesChartType.Spline
                                    : SeriesChartType.FastPoint;
            style.LineWidth      = (int)numLineWidth.Value;
            style.LineColor      = btnLineColor.BackColor;
            style.BackgroundColor = btnBackColor.BackColor;
            this.DialogResult = DialogResult.OK;
        }
    }
}
