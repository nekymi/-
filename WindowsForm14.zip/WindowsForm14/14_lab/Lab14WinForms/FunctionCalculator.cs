﻿using System;

namespace Lab14WinForms
{
    public delegate double Fun(double x);

    public static class FunctionCalculator
    {
        public static void Compute(
            Fun f,
            double Xn,
            double Xk,
            double dX,
            bool inDegrees,
            out double[] xValues,
            out double[] yValues)
        {
            int n = (int)Math.Ceiling((Xk - Xn) / dX) + 1;
            xValues = new double[n];
            yValues = new double[n];
            double x = Xn;
            for (int i = 0; i < n; i++)
            {
                double arg = inDegrees ? x * Math.PI / 180.0 : x;
                xValues[i] = x;
                yValues[i] = f(arg);
                x += dX;
            }
        }
    }
}
