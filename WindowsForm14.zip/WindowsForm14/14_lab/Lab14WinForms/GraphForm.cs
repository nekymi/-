﻿// GraphForm.cs
using System;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Lab14WinForms
{
    public partial class GraphForm : Form
    {
        private readonly DiagramStyle diagramStyle;

        public GraphForm(DiagramStyle style)
        {
            InitializeComponent();
            diagramStyle = style;
            btnSave.Click += btnSave_Click;
        }

        public void RefreshDiagram(double[] xs, double[] ys, string title)
        {
            chart1.Series.Clear();
            chart1.Titles.Clear();
            chart1.Legends.Clear();

            chart1.BackColor = diagramStyle.BackgroundColor;

            // Убедимся, что есть хотя бы одна область
            if (chart1.ChartAreas.Count == 0)
            {
                chart1.ChartAreas.Add(new ChartArea("Default"));
            }

            string areaName = chart1.ChartAreas[0].Name;

            var series = new Series(title)
            {
                ChartType = diagramStyle.ChartType,
                BorderWidth = diagramStyle.LineWidth,
                Color = diagramStyle.LineColor,
                ChartArea = areaName
            };
            chart1.Series.Add(series);

            // заголовок
            if (diagramStyle.ShowTitle && !string.IsNullOrWhiteSpace(title))
            {
                Title chartTitle = new Title(title)
                {
                    Font = new System.Drawing.Font(
                        diagramStyle.TitleFontName,
                        diagramStyle.TitleFontSize)
                };
                chart1.Titles.Add(chartTitle);
            }

            // легенда
            if (diagramStyle.ShowLegend)
                chart1.Legends.Add(title);

            // привязываем данные
            series.Points.DataBindXY(xs, ys);
            series.ToolTip = "X = #VALX, Y = #VALY";

            chart1.Invalidate();
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            using (var dlg = new SaveFileDialog())
            {
                dlg.Filter = "PNG‑файлы|*.png";
                if (dlg.ShowDialog() == DialogResult.OK)
                    chart1.SaveImage(dlg.FileName, ChartImageFormat.Png);
            }
        }
    }
}
// Изменено: Assistant
