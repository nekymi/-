﻿using System;
using ArrayLibrary;

class Program
{
    static void Main()
    {
        Arr a = new Arr(5);
        a.FillRandom();
        Console.WriteLine("Массив A:");
        a.Print();

        Console.WriteLine($"Количество перемен знака: {a.CountSignChanges()}");

        Arr b = ++a;
        Console.WriteLine("Массив B (A++):");
        b.Print();

        Arr c = a + b;
        Console.WriteLine("Массив C = A + B:");
        c.Print();
        Console.ReadKey();
    }
}
