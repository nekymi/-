﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.numericUpDownSize1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownSize2 = new System.Windows.Forms.NumericUpDown();
            this.radioButtonRandom1 = new System.Windows.Forms.RadioButton();
            this.radioButtonFile1 = new System.Windows.Forms.RadioButton();
            this.radioButtonRandom2 = new System.Windows.Forms.RadioButton();
            this.radioButtonFile2 = new System.Windows.Forms.RadioButton();
            this.buttonLoad1 = new System.Windows.Forms.Button();
            this.buttonLoad2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewResult = new System.Windows.Forms.DataGridView();
            this.buttonIncrement = new System.Windows.Forms.Button();
            this.buttonDecrement = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonSubtract = new System.Windows.Forms.Button();
            this.buttonSignChange = new System.Windows.Forms.Button();
            this.labelSignChanges = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSize1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSize2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResult)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // numericUpDownSize1
            // 
            this.numericUpDownSize1.Location = new System.Drawing.Point(16, 39);
            this.numericUpDownSize1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.numericUpDownSize1.Name = "numericUpDownSize1";
            this.numericUpDownSize1.Size = new System.Drawing.Size(160, 22);
            this.numericUpDownSize1.TabIndex = 0;
            // 
            // numericUpDownSize2
            // 
            this.numericUpDownSize2.Location = new System.Drawing.Point(16, 124);
            this.numericUpDownSize2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.numericUpDownSize2.Name = "numericUpDownSize2";
            this.numericUpDownSize2.Size = new System.Drawing.Size(160, 22);
            this.numericUpDownSize2.TabIndex = 1;
            // 
            // radioButtonRandom1
            // 
            this.radioButtonRandom1.AutoSize = true;
            this.radioButtonRandom1.Location = new System.Drawing.Point(6, 22);
            this.radioButtonRandom1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButtonRandom1.Name = "radioButtonRandom1";
            this.radioButtonRandom1.Size = new System.Drawing.Size(194, 20);
            this.radioButtonRandom1.TabIndex = 2;
            this.radioButtonRandom1.TabStop = true;
            this.radioButtonRandom1.Text = "Случайное заполнение 1";
            this.radioButtonRandom1.UseVisualStyleBackColor = true;
            // 
            // radioButtonFile1
            // 
            this.radioButtonFile1.AutoSize = true;
            this.radioButtonFile1.Location = new System.Drawing.Point(6, 50);
            this.radioButtonFile1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButtonFile1.Name = "radioButtonFile1";
            this.radioButtonFile1.Size = new System.Drawing.Size(158, 20);
            this.radioButtonFile1.TabIndex = 3;
            this.radioButtonFile1.TabStop = true;
            this.radioButtonFile1.Text = "Загрузка массива 1";
            this.radioButtonFile1.UseVisualStyleBackColor = true;
            // 
            // radioButtonRandom2
            // 
            this.radioButtonRandom2.AutoSize = true;
            this.radioButtonRandom2.Location = new System.Drawing.Point(5, 22);
            this.radioButtonRandom2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButtonRandom2.Name = "radioButtonRandom2";
            this.radioButtonRandom2.Size = new System.Drawing.Size(194, 20);
            this.radioButtonRandom2.TabIndex = 4;
            this.radioButtonRandom2.TabStop = true;
            this.radioButtonRandom2.Text = "Случайное заполнение 2";
            this.radioButtonRandom2.UseVisualStyleBackColor = true;
            // 
            // radioButtonFile2
            // 
            this.radioButtonFile2.AutoSize = true;
            this.radioButtonFile2.Location = new System.Drawing.Point(5, 50);
            this.radioButtonFile2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButtonFile2.Name = "radioButtonFile2";
            this.radioButtonFile2.Size = new System.Drawing.Size(158, 20);
            this.radioButtonFile2.TabIndex = 5;
            this.radioButtonFile2.TabStop = true;
            this.radioButtonFile2.Text = "Загрузка массива 2";
            this.radioButtonFile2.UseVisualStyleBackColor = true;
            // 
            // buttonLoad1
            // 
            this.buttonLoad1.Location = new System.Drawing.Point(16, 192);
            this.buttonLoad1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonLoad1.Name = "buttonLoad1";
            this.buttonLoad1.Size = new System.Drawing.Size(171, 28);
            this.buttonLoad1.TabIndex = 6;
            this.buttonLoad1.Text = "Загрузить массив 1";
            this.buttonLoad1.UseVisualStyleBackColor = true;
            this.buttonLoad1.Click += new System.EventHandler(this.buttonLoad1_Click);
            // 
            // buttonLoad2
            // 
            this.buttonLoad2.Location = new System.Drawing.Point(227, 192);
            this.buttonLoad2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonLoad2.Name = "buttonLoad2";
            this.buttonLoad2.Size = new System.Drawing.Size(165, 28);
            this.buttonLoad2.TabIndex = 7;
            this.buttonLoad2.Text = "Загрузить массив 2";
            this.buttonLoad2.UseVisualStyleBackColor = true;
            this.buttonLoad2.Click += new System.EventHandler(this.buttonLoad2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(516, 111);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(538, 109);
            this.dataGridView1.TabIndex = 8;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(516, 258);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(538, 108);
            this.dataGridView2.TabIndex = 9;
            // 
            // dataGridViewResult
            // 
            this.dataGridViewResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewResult.Location = new System.Drawing.Point(13, 416);
            this.dataGridViewResult.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridViewResult.Name = "dataGridViewResult";
            this.dataGridViewResult.RowHeadersWidth = 51;
            this.dataGridViewResult.Size = new System.Drawing.Size(494, 108);
            this.dataGridViewResult.TabIndex = 10;
            // 
            // buttonIncrement
            // 
            this.buttonIncrement.Location = new System.Drawing.Point(529, 39);
            this.buttonIncrement.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonIncrement.Name = "buttonIncrement";
            this.buttonIncrement.Size = new System.Drawing.Size(48, 41);
            this.buttonIncrement.TabIndex = 11;
            this.buttonIncrement.Text = "++";
            this.buttonIncrement.UseVisualStyleBackColor = true;
            this.buttonIncrement.Click += new System.EventHandler(this.buttonIncrement_Click);
            // 
            // buttonDecrement
            // 
            this.buttonDecrement.Location = new System.Drawing.Point(598, 39);
            this.buttonDecrement.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonDecrement.Name = "buttonDecrement";
            this.buttonDecrement.Size = new System.Drawing.Size(48, 41);
            this.buttonDecrement.TabIndex = 12;
            this.buttonDecrement.Text = "--";
            this.buttonDecrement.UseVisualStyleBackColor = true;
            this.buttonDecrement.Click += new System.EventHandler(this.buttonDecrement_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(679, 35);
            this.buttonAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(116, 57);
            this.buttonAdd.TabIndex = 13;
            this.buttonAdd.Text = "Сложение массивов";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonSubtract
            // 
            this.buttonSubtract.Location = new System.Drawing.Point(817, 35);
            this.buttonSubtract.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonSubtract.Name = "buttonSubtract";
            this.buttonSubtract.Size = new System.Drawing.Size(116, 57);
            this.buttonSubtract.TabIndex = 14;
            this.buttonSubtract.Text = "\tВычитание массивов";
            this.buttonSubtract.UseVisualStyleBackColor = true;
            this.buttonSubtract.Click += new System.EventHandler(this.buttonSubtract_Click);
            // 
            // buttonSignChange
            // 
            this.buttonSignChange.Location = new System.Drawing.Point(43, 322);
            this.buttonSignChange.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonSignChange.Name = "buttonSignChange";
            this.buttonSignChange.Size = new System.Drawing.Size(159, 57);
            this.buttonSignChange.TabIndex = 15;
            this.buttonSignChange.Text = "Подсчёт перемен знака в массиве 1";
            this.buttonSignChange.UseVisualStyleBackColor = true;
            this.buttonSignChange.Click += new System.EventHandler(this.buttonSignChange_Click);
            // 
            // labelSignChanges
            // 
            this.labelSignChanges.AutoSize = true;
            this.labelSignChanges.Location = new System.Drawing.Point(251, 342);
            this.labelSignChanges.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSignChanges.Name = "labelSignChanges";
            this.labelSignChanges.Size = new System.Drawing.Size(0, 16);
            this.labelSignChanges.TabIndex = 16;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonRandom1);
            this.groupBox1.Controls.Add(this.radioButtonFile1);
            this.groupBox1.Location = new System.Drawing.Point(192, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 72);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Для массива 1:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButtonRandom2);
            this.groupBox2.Controls.Add(this.radioButtonFile2);
            this.groupBox2.Location = new System.Drawing.Point(198, 102);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 75);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Для массива 2:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.labelSignChanges);
            this.Controls.Add(this.buttonSignChange);
            this.Controls.Add(this.buttonSubtract);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.buttonDecrement);
            this.Controls.Add(this.buttonIncrement);
            this.Controls.Add(this.dataGridViewResult);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonLoad2);
            this.Controls.Add(this.buttonLoad1);
            this.Controls.Add(this.numericUpDownSize2);
            this.Controls.Add(this.numericUpDownSize1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Программа для работы с массивами";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSize1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSize2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResult)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numericUpDownSize1;
        private System.Windows.Forms.NumericUpDown numericUpDownSize2;
        private System.Windows.Forms.RadioButton radioButtonRandom1;
        private System.Windows.Forms.RadioButton radioButtonFile1;
        private System.Windows.Forms.RadioButton radioButtonRandom2;
        private System.Windows.Forms.RadioButton radioButtonFile2;
        private System.Windows.Forms.Button buttonLoad1;
        private System.Windows.Forms.Button buttonLoad2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridViewResult;
        private System.Windows.Forms.Button buttonIncrement;
        private System.Windows.Forms.Button buttonDecrement;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonSubtract;
        private System.Windows.Forms.Button buttonSignChange;
        private System.Windows.Forms.Label labelSignChanges;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

