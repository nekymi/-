﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using ArrayLibrary;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private Arr arr1;
        private Arr arr2;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonLoad1_Click(object sender, EventArgs e)
        {
            int size = (int)numericUpDownSize1.Value;
            arr1 = new Arr(size);
            if (radioButtonRandom1.Checked)
            {
                arr1.FillRandom();
            }
            else
            {
                OpenFileDialog dialog = new OpenFileDialog();
                if (dialog.ShowDialog() == DialogResult.OK)
                    arr1.LoadFromFile(dialog.FileName);
            }

            DisplayArray(arr1, dataGridView1);
        }

        private void buttonLoad2_Click(object sender, EventArgs e)
        {
            int size = (int)numericUpDownSize2.Value;
            arr2 = new Arr(size);
            if (radioButtonRandom2.Checked)
            {
                arr2.FillRandom();
            }
            else
            {
                OpenFileDialog dialog = new OpenFileDialog();
                if (dialog.ShowDialog() == DialogResult.OK)
                    arr2.LoadFromFile(dialog.FileName);
            }

            DisplayArray(arr2, dataGridView2);
        }

        private void buttonIncrement_Click(object sender, EventArgs e)
        {
            if (arr1 != null)
            {
                arr1 = ++arr1;
                DisplayArray(arr1, dataGridView1);
            }
        }

        private void buttonDecrement_Click(object sender, EventArgs e)
        {
            if (arr1 != null)
            {
                arr1 = --arr1;
                DisplayArray(arr1, dataGridView1);
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (arr1 != null && arr2 != null)
            {
                Arr result = arr1 + arr2;
                DisplayArray(result, dataGridViewResult);
            }
        }

        private void buttonSubtract_Click(object sender, EventArgs e)
        {
            if (arr1 != null && arr2 != null)
            {
                Arr result = arr1 - arr2;
                DisplayArray(result, dataGridViewResult);
            }
        }

        private void buttonSignChange_Click(object sender, EventArgs e)
        {
            if (arr1 != null)
            {
                int count = arr1.CountSignChanges();
                labelSignChanges.Text = $"Перемен знака: {count}";
            }
        }

        private void DisplayArray(Arr arr, DataGridView grid)
        {
            grid.Rows.Clear();
            grid.Columns.Clear();
            var data = arr.ToArray();
            for (int i = 0; i < data.Length; i++)
                grid.Columns.Add($"col{i}", i.ToString());
            grid.Rows.Add(data.Cast<object>().ToArray());
        }
    }
}
