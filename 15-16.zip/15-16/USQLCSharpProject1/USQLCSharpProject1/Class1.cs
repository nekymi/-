﻿using Microsoft.Analytics.Interfaces;
using Microsoft.Analytics.Interfaces.Streaming;
using Microsoft.Analytics.Types.Sql;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ArrayLibrary
{
    /// <summary>
    /// Класс для работы с одномерным массивом целых чисел
    /// </summary>
    public class Arr
    {
        private int[] array;

        /// <summary>
        /// Конструктор по размеру
        /// </summary>
        public Arr(int size)
        {
            array = new int[size];
        }

        /// <summary>
        /// Конструктор по массиву
        /// </summary>
        public Arr(int[] data)
        {
            array = (int[])data.Clone();
        }

        /// <summary>
        /// Заполнение случайными числами
        /// </summary>
        public void FillRandom(int min = -10, int max = 10)
        {
            Random rnd = new Random();
            for (int i = 0; i < array.Length; i++)
                array[i] = rnd.Next(min, max + 1);
        }

        /// <summary>
        /// Загрузка из строки
        /// </summary>
        public void LoadFromString(string str)
        {
            array = str.Split(' ')
                       .Select(s => int.Parse(s))
                       .ToArray();
        }

        /// <summary>
        /// Загрузка из файла
        /// </summary>
        public void LoadFromFile(string path)
        {
            string content = File.ReadAllText(path);
            LoadFromString(content);
        }

        /// <summary>
        /// Преобразование массива в строку
        /// </summary>
        public override string ToString()
        {
            return string.Join(" ", array);
        }

        /// <summary>
        /// Сравнение массивов
        /// </summary>
        public override bool Equals(object obj)
        {
            if (obj is Arr other)
                return array.SequenceEqual(other.array);
            return false;
        }

        public override int GetHashCode()
        {
            return array.Aggregate(17, (acc, val) => acc * 31 + val.GetHashCode());
        }

        /// <summary>
        /// Вывод в консоль
        /// </summary>
        public void Print()
        {
            Console.WriteLine(ToString());
        }

        /// <summary>
        /// Получить массив (копию)
        /// </summary>
        public int[] ToArray() => (int[])array.Clone();

        /// <summary>
        /// Перегрузка ++
        /// </summary>
        public static Arr operator ++(Arr a)
        {
            return new Arr(a.array.Select(x => x + 1).ToArray());
        }

        /// <summary>
        /// Перегрузка --
        /// </summary>
        public static Arr operator --(Arr a)
        {
            return new Arr(a.array.Select(x => x - 1).ToArray());
        }

        /// <summary>
        /// Перегрузка + для двух массивов
        /// </summary>
        public static Arr operator +(Arr a, Arr b)
        {
            int length = Math.Max(a.array.Length, b.array.Length);
            int[] result = new int[length];
            for (int i = 0; i < length; i++)
            {
                int valA = i < a.array.Length ? a.array[i] : 0;
                int valB = i < b.array.Length ? b.array[i] : 0;
                result[i] = valA + valB;
            }
            return new Arr(result);
        }

        /// <summary>
        /// Перегрузка - для двух массивов
        /// </summary>
        public static Arr operator -(Arr a, Arr b)
        {
            int length = Math.Max(a.array.Length, b.array.Length);
            int[] result = new int[length];
            for (int i = 0; i < length; i++)
            {
                int valA = i < a.array.Length ? a.array[i] : 0;
                int valB = i < b.array.Length ? b.array[i] : 0;
                result[i] = valA - valB;
            }
            return new Arr(result);
        }

        /// <summary>
        /// Перегрузка + для массива и числа
        /// </summary>
        public static Arr operator +(Arr a, int number)
        {
            return new Arr(a.array.Select(x => x + number).ToArray());
        }

        /// <summary>
        /// Перегрузка - для массива и числа
        /// </summary>
        public static Arr operator -(Arr a, int number)
        {
            return new Arr(a.array.Select(x => x - number).ToArray());
        }

        /// <summary>
        /// Подсчёт количества перемен знака
        /// </summary>
        public int CountSignChanges()
        {
            int count = 0;
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i - 1] != 0 && array[i] != 0 &&
                    (array[i - 1] > 0 && array[i] < 0 || array[i - 1] < 0 && array[i] > 0))
                {
                    count++;
                }
            }
            return count;
        }
    }
}