﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ArrayLibrary;

namespace UnitTestProject2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestIncrementOperator()
        {
            Arr arr = new Arr(new int[] { 1, -1, 0 });
            Arr result = ++arr;
            Arr expected = new Arr(new int[] { 2, 0, 1 });
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void TestArrayAddition()
        {
            Arr a = new Arr(new int[] { 1, 2 });
            Arr b = new Arr(new int[] { 3, 4, 5 });
            Arr result = a + b;
            Arr expected = new Arr(new int[] { 4, 6, 5 });
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void TestCountSignChanges_Positive()
        {
            Arr arr = new Arr(new int[] { 1, -2, 3, -4 });

            int result = arr.CountSignChanges();

            Assert.AreEqual(3, result, "Ожидалось 3 перемены знака.");
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void TestLoadFromInvalidString()
        {
            Arr arr = new Arr(1);
            arr.LoadFromString("10 a 5");
        }
    }
}
